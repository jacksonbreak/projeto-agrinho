let solCor;
let tratorX;
let plantas = [];
let score = 0; // Pontos de coleta no campo
let pontosDeVenda = 0; // Novos pontos de venda no mercado

let velocidadeAtualTrator = 0;
let aceleracaoTrator = 0.5;
let friccaoTrator = 0.9;
let velocidadeMaximaTrator = 8;
let velocidadeBaseTrator = 8; // Velocidade máxima inicial do trator

let tempoParaReplantio = 300;

let cenarioAtual = 'campo';
let botaoTrocarCenario;

// --- Variáveis para os carros da cidade ---
let carros = [];
let numCarros = 4;
let velocidadeCarroMin = 1;
let velocidadeCarroMax = 3;
let distanciaMinimaCarros = 120;

// --- Variáveis para as nuvens e chuva ---
let nuvens = [];
let numNuvens = 5;
let chuva = [];
let chovendo = false;
let gravidadeChuva = 0.1;

// --- Variáveis para o caminhão de entrega (Trator no modo "caminhão") ---
let tratorCarregado = 0; // Quantidade de plantas que o trator está carregando

// --- Variáveis para a Loja de Melhorias ---
let melhoriaVelocidadeCusto = 50; // Custo inicial para melhorar a velocidade
let melhoriaVelocidadeNivel = 0; // Nível atual da melhoria de velocidade
let melhoriaVelocidadeAumento = 2; // Quanto a velocidade aumenta por nível

function setup() {
  createCanvas(700, 400);
  solCor = color(255, 255, 0);

  tratorX = width / 2;

  // --- Cria as Plantações Iniciais ---
  for (let i = 20; i < width - 20; i += 30) {
    plantas.push({
      x: i,
      y: height - 150,
      w: 15,
      h: 25,
      cor: color(34, 139, 34),
      coletada: false,
      tempoColetado: 0
    });
    plantas.push({
      x: i + 10,
      y: height - 125,
      w: 10,
      h: 10,
      cor: color(200, 200, 0),
      coletada: false,
      tempoColetado: 0
    });
  }

  // --- Cria os Carros Iniciais para o cenário da cidade ---
  for (let i = 0; i < numCarros; i++) {
    let novoCarro = criarNovoCarro();
    novoCarro.x = -(i * distanciaMinimaCarros + random(0, 50));
    carros.push(novoCarro);
  }

  // --- Cria as Nuvens ---
  for (let i = 0; i < numNuvens; i++) {
    nuvens.push(criarNovaNuvem());
  }

  // --- Cria o Botão para Trocar de Cenário ---
  botaoTrocarCenario = createButton('Ir para a Cidade');
  botaoTrocarCenario.position(10, 100);
  botaoTrocarCenario.mousePressed(trocarCenario);
}

function draw() {
  if (cenarioAtual === 'campo') {
    desenharCenarioCampo();
  } else {
    desenharCenarioCidade();
  }

  // --- Informações na Tela ---
  fill(0);
  textSize(14);
  text("Use 'A' e 'D' para mover o veículo", 10, 20);
  text("Clique nas nuvens para chover!", 10, 40);

  if (cenarioAtual === 'campo') {
    text("Plantações Coletadas: " + score, 10, 60);
    text("As plantas renascem!", 10, 80);
    text("Carregado: " + tratorCarregado + " plantas", 10, 120);
  } else { // No cenário da cidade
    text("Pontos de Venda: " + pontosDeVenda, 10, 60);
    text("Plantas Carregadas: " + tratorCarregado, 10, 80);
    text("Velocidade do Veículo: " + velocidadeMaximaTrator, 10, 120);
    text("Nível Melhoria Velocidade: " + melhoriaVelocidadeNivel, 10, 140);
  }
}

// --- Funções Auxiliares para Carros ---
function criarNovoCarro() {
  let carroMaisAEsquerda = 0;
  if (carros.length > 0) {
    carroMaisAEsquerda = width;
    for (let i = 0; i < carros.length; i++) {
      if (carros[i].x < carroMaisAEsquerda) {
        carroMaisAEsquerda = carros[i].x;
      }
    }
  }

  let novaPosX = random(-distanciaMinimaCarros * 2, -distanciaMinimaCarros);

  return {
    x: novaPosX,
    y: height - random(40, 80),
    largura: random(50, 80),
    altura: random(20, 30),
    cor: color(random(255), random(255), random(255)),
    velocidade: random(velocidadeCarroMin, velocidadeCarroMax)
  };
}

function desenharCarro(carro) {
  push();
  fill(carro.cor);
  rect(carro.x, carro.y, carro.largura, carro.altura);

  fill(0);
  ellipse(carro.x + carro.largura * 0.25, carro.y + carro.altura, 15, 15);
  ellipse(carro.x + carro.largura * 0.75, carro.y + carro.altura, 15, 15);
  pop();
}

// --- Funções Auxiliares para Nuvens e Chuva ---
function criarNovaNuvem() {
  return {
    x: random(0, width - 50),
    y: random(20, 100),
    largura: random(50, 100),
    altura: random(20, 40),
    cor: color(255),
    raio: 20
  };
}

function desenharNuvem(nuvem) {
  fill(nuvem.cor);
  noStroke();
  ellipse(nuvem.x, nuvem.y, nuvem.largura, nuvem.altura);
  ellipse(nuvem.x - nuvem.largura * 0.2, nuvem.y + nuvem.altura * 0.1, nuvem.largura * 0.7, nuvem.altura * 0.8);
  ellipse(nuvem.x + nuvem.largura * 0.3, nuvem.y - nuvem.altura * 0.1, nuvem.largura * 0.6, nuvem.altura * 0.9);
}

function iniciarChuva(nuvemX, nuvemY) {
  chuva = [];
  chovendo = true;
  for (let i = 0; i < 100; i++) {
    chuva.push({
      x: random(nuvemX - 20, nuvemX + 20),
      y: nuvemY + 20,
      comprimento: random(5, 15)
    });
  }
}

function desenharChuva() {
  if (chovendo) {
    for (let i = chuva.length - 1; i >= 0; i--) {
      stroke(0, 0, 255, 150);
      strokeWeight(1);
      line(chuva[i].x, chuva[i].y, chuva[i].x, chuva[i].y + chuva[i].comprimento);
      chuva[i].y += 5;

      if (chuva[i].y > height) {
        chuva.splice(i, 1);
      }
    }
    if (chuva.length === 0) {
      chovendo = false;
    }
  }
}

function desenharCenarioCampo() {
  background(135, 206, 235);

  // Sol (cor fixa)
  fill(solCor);
  ellipse(width - 80, 80, 100, 100);

  // Chão da Fazenda (Terra)
  fill(139, 69, 19);
  rect(0, height - 120, width, 120);

  // Celeiro
  fill(178, 34, 34);
  rect(80, height - 280, 150, 160);
  fill(139, 69, 19);
  triangle(70, height - 280, 240, height - 280, 155, height - 350);
  fill(0);
  rect(130, height - 180, 50, 60);

  // --- Lógica de Movimento do Trator (Aceleração/Desaceleração) ---
  if (keyIsDown(65)) { // Tecla A
    velocidadeAtualTrator -= aceleracaoTrator;
  }
  if (keyIsDown(68)) { // Tecla D
    velocidadeAtualTrator += aceleracaoTrator;
  }
  if (!keyIsDown(65) && !keyIsDown(68)) {
    velocidadeAtualTrator *= friccaoTrator;
    if (abs(velocidadeAtualTrator) < 0.1) {
      velocidadeAtualTrator = 0;
    }
  }
  velocidadeAtualTrator = constrain(velocidadeAtualTrator, -velocidadeMaximaTrator, velocidadeMaximaTrator);
  tratorX += velocidadeAtualTrator;
  tratorX = constrain(tratorX, 40, width - 40);

  // --- Trator ---
  let tratorY = height - 90;
  fill(0, 100, 0); // Cor do trator
  rect(tratorX - 40, tratorY - 30, 80, 30); // Corpo
  rect(tratorX - 20, tratorY - 50, 40, 20); // Cabine
  fill(50); // Cor das rodas
  ellipse(tratorX - 25, tratorY, 30, 30); // Roda traseira
  ellipse(tratorX + 25, tratorY, 20, 20); // Roda dianteira

  // Desenha a carga no trator se houver
  if (tratorCarregado > 0) {
    fill(200, 200, 0); // Cor de sacas ou caixas
    rect(tratorX - 30, tratorY - 20, 60, 15); // Representa a carga
  }


  // --- Desenha as Plantações e Lógica de Coleta/Replantio ---
  let tratorColheitaYMin = tratorY - 50;
  let tratorColheitaYMax = tratorY + 10;

  for (let i = 0; i < plantas.length; i++) {
    if (plantas[i].coletada) {
      plantas[i].tempoColetado++;
      if (plantas[i].tempoColetado >= tempoParaReplantio) {
        plantas[i].coletada = false;
        plantas[i].tempoColetado = 0;
      }
    } else {
      fill(plantas[i].cor);
      rect(plantas[i].x, plantas[i].y, plantas[i].w, plantas[i].h);

      // Lógica de Coleta (Colisão)
      let tratorEsquerda = tratorX - 40;
      let tratorDireita = tratorX + 40;
      let plantaEsquerda = plantas[i].x;
      let plantaDireita = plantas[i].x + plantas[i].w;
      let plantaTopo = plantas[i].y;
      let plantaBase = plantas[i].y + plantas[i].h;

      if (tratorDireita > plantaEsquerda && tratorEsquerda < plantaDireita &&
        tratorColheitaYMax > plantaTopo && tratorColheitaYMin < plantaBase) {
        plantas[i].coletada = true;
        plantas[i].tempoColetado = 0;
        score++; // Aumenta pontos de coleta
        tratorCarregado++; // Aumenta a carga do trator
      }
    }
  }

  // --- Desenha as Nuvens ---
  for (let i = 0; i < nuvens.length; i++) {
    desenharNuvem(nuvens[i]);
  }

  // --- Desenha a Chuva ---
  desenharChuva();
}

// --- Função para Desenhar o Cenário da Cidade ---
function desenharCenarioCidade() {
  background(100, 150, 200);

  // Sol/Lua
  fill(solCor);
  ellipse(width - 80, 80, 80, 80);

  // Rua
  fill(80);
  rect(0, height - 100, width, 100);
  // Faixas da rua
  for (let i = 0; i < width; i += 60) {
    fill(255, 255, 0);
    rect(i + 10, height - 55, 30, 5);
  }

  // Prédios
  fill(150);
  rect(100, height - 250, 120, 150);
  fill(200);
  rect(110, height - 240, 20, 20);
  rect(140, height - 240, 20, 20);
  rect(170, height - 240, 20, 20);
  rect(110, height - 210, 20, 20);
  rect(140, height - 210, 20, 20);
  rect(170, height - 210, 20, 20);

  fill(120);
  rect(250, height - 300, 100, 200);
  fill(200);
  rect(260, height - 290, 15, 15);
  rect(285, height - 290, 15, 15);
  rect(310, height - 290, 15, 15);
  rect(260, height - 265, 15, 15);
  rect(285, height - 265, 15, 15);
  rect(310, height - 265, 15, 15);

  // --- Desenha o Mercado ---
  desenharMercado();

  // --- Desenha a Loja de Melhorias ---
  desenharLojaMelhorias();

  // Pessoas na cidade
  fill(0);
  ellipse(400, height - 120, 20, 30);
  ellipse(450, height - 110, 20, 30);

  // --- Lógica de Movimento do Caminhão (trator) ---
  if (keyIsDown(65)) { // Tecla A
    velocidadeAtualTrator -= aceleracaoTrator;
  }
  if (keyIsDown(68)) { // Tecla D
    velocidadeAtualTrator += aceleracaoTrator;
  }
  if (!keyIsDown(65) && !keyIsDown(68)) {
    velocidadeAtualTrator *= friccaoTrator;
    if (abs(velocidadeAtualTrator) < 0.1) {
      velocidadeAtualTrator = 0;
    }
  }
  velocidadeAtualTrator = constrain(velocidadeAtualTrator, -velocidadeMaximaTrator, velocidadeMaximaTrator);
  tratorX += velocidadeAtualTrator;
  tratorX = constrain(tratorX, 40, width - 40);

  // --- Desenha o Caminhão de Entrega (Trator reestilizado) ---
  let caminhaoY = height - 90;
  fill(0, 50, 150); // Cor azul para o caminhão
  rect(tratorX - 50, caminhaoY - 30, 100, 30); // Carroceria
  rect(tratorX + 10, caminhaoY - 50, 40, 20); // Cabine
  fill(50); // Cor das rodas
  ellipse(tratorX - 35, caminhaoY, 25, 25);
  ellipse(tratorX + 35, caminhaoY, 25, 25);

  // Desenha a carga no caminhão se houver
  if (tratorCarregado > 0) {
    fill(200, 200, 0); // Cor de sacas ou caixas
    rect(tratorX - 40, caminhaoY - 20, 80, 15); // Representa a carga
  }


  // --- Lógica de Venda no Mercado ---
  // Verifica se o caminhão está perto do mercado E tem plantas carregadas
  let distanciaAoMercado = dist(tratorX, caminhaoY, width - 125, height - 100); // Ponto de referência do mercado
  if (distanciaAoMercado < 80 && tratorCarregado > 0) { // Distância para "descarregar"
    pontosDeVenda += tratorCarregado; // Adiciona as plantas carregadas aos pontos de venda
    tratorCarregado = 0; // Zera a carga do caminhão
  }

  // --- Movimento e Desenho dos Carros ---
  for (let i = 0; i < carros.length; i++) {
    let carro = carros[i];

    desenharCarro(carro);

    carro.x += carro.velocidade;

    if (carro.x > width + 50) {
      carros[i] = criarNovoCarro();
    }
  }

  // --- Desenha as Nuvens ---
  for (let i = 0; i < nuvens.length; i++) {
    desenharNuvem(nuvens[i]);
  }

  // --- Desenha a Chuva ---
  desenharChuva();
}

// --- Função para Desenhar o Mercado ---
function desenharMercado() {
  // Base do mercado
  fill(200, 100, 50); // Cor de tijolo ou madeira
  rect(width - 200, height - 230, 150, 130); // Posição e tamanho do mercado

  // Telhado do mercado
  fill(150, 50, 0); // Cor mais escura para o telhado
  triangle(width - 210, height - 230, width - 40, height - 230, width - 125, height - 280);

  // Porta
  fill(100, 50, 0); // Cor da porta
  rect(width - 150, height - 170, 50, 70);

  // Placa "Mercado"
  fill(255); // Cor da placa
  rect(width - 175, height - 215, 100, 25);
  fill(0); // Cor do texto
  textSize(18);
  textAlign(CENTER, CENTER);
  text("Mercado", width - 125, height - 202);
  textAlign(LEFT, BASELINE); // Volta ao alinhamento padrão
  textSize(14); // Volta ao tamanho de texto padrão
}

// --- Função para Desenhar a Loja de Melhorias ---
function desenharLojaMelhorias() {
  let lojaX = 20; // Posição X da loja
  let lojaY = height - 230; // Posição Y da loja

  // Base da loja
  fill(180, 180, 180); // Cor cinza para a loja
  rect(lojaX, lojaY, 120, 130);

  // Telhado da loja
  fill(100, 100, 100); // Cor mais escura para o telhado
  triangle(lojaX - 10, lojaY, lojaX + 130, lojaY, lojaX + 60, lojaY - 50);

  // Placa "Loja"
  fill(255, 200, 0); // Cor da placa (amarelo alaranjado)
  rect(lojaX + 10, lojaY + 10, 100, 25);
  fill(0); // Cor do texto
  textSize(18);
  textAlign(CENTER, CENTER);
  text("Loja", lojaX + 60, lojaY + 22);
  textAlign(LEFT, BASELINE);
  textSize(14);

  // Botão de melhoria de velocidade
  let btnVelocidadeX = lojaX + 20;
  let btnVelocidadeY = lojaY + 50;
  let btnLargura = 80;
  let btnAltura = 25;

  // Cor do botão: verde se puder comprar, vermelho se não
  if (pontosDeVenda >= melhoriaVelocidadeCusto) {
    fill(0, 180, 0);
  } else {
    fill(180, 0, 0);
  }
  rect(btnVelocidadeX, btnVelocidadeY, btnLargura, btnAltura);
  fill(255);
  textSize(12);
  text("Velocidade", btnVelocidadeX + btnLargura / 2, btnVelocidadeY + btnAltura / 2 - 5);
  text("Custo: " + melhoriaVelocidadeCusto, btnVelocidadeX + btnLargura / 2, btnVelocidadeY + btnAltura / 2 + 5);
}


// --- Função que troca o cenário quando o botão é clicado ---
function trocarCenario() {
  if (cenarioAtual === 'campo') {
    cenarioAtual = 'cidade';
    botaoTrocarCenario.html('Voltar para o Campo');
    velocidadeAtualTrator = 0;
  } else {
    cenarioAtual = 'campo';
    botaoTrocarCenario.html('Ir para a Cidade');
    velocidadeAtualTrator = 0;
    tratorX = width / 2;
  }
}

// --- Funções de interação ---
function mousePressed() {
  // Nuvens interativas em ambos os cenários
  if (cenarioAtual === 'campo' || cenarioAtual === 'cidade') {
    for (let i = 0; i < nuvens.length; i++) {
      let distanciaNuvem = dist(mouseX, mouseY, nuvens[i].x, nuvens[i].y);
      if (distanciaNuvem < nuvens[i].raio) {
        iniciarChuva(nuvens[i].x, nuvens[i].y);
      }
    }
  }

  // Lógica de clique na Loja de Melhorias (apenas na cidade)
  if (cenarioAtual === 'cidade') {
    let lojaX = 20;
    let lojaY = height - 230;
    let btnVelocidadeX = lojaX + 20;
    let btnVelocidadeY = lojaY + 50;
    let btnLargura = 80;
    let btnAltura = 25;

    // Verifica se clicou no botão de melhoria de velocidade
    if (mouseX > btnVelocidadeX && mouseX < btnVelocidadeX + btnLargura &&
        mouseY > btnVelocidadeY && mouseY < btnVelocidadeY + btnAltura) {
      comprarMelhoriaVelocidade();
    }
  }
}

// --- Função para comprar melhoria de velocidade ---
function comprarMelhoriaVelocidade() {
  if (pontosDeVenda >= melhoriaVelocidadeCusto) {
    pontosDeVenda -= melhoriaVelocidadeCusto; // Reduz o custo
    velocidadeMaximaTrator += melhoriaVelocidadeAumento; // Aumenta a velocidade máxima
    melhoriaVelocidadeNivel++; // Aumenta o nível da melhoria
    melhoriaVelocidadeCusto = round(melhoriaVelocidadeCusto * 1.5); // Aumenta o custo para a próxima melhoria (arredondado)
    console.log("Velocidade melhorada! Novo nível: " + melhoriaVelocidadeNivel + ", Velocidade: " + velocidadeMaximaTrator);
  } else {
    console.log("Pontos de venda insuficientes para melhorar a velocidade.");
  }
}